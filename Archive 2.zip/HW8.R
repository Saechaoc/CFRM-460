bsc <- function(S, T, t, K, r, s, q) {
d1 <- (log(S/K)+(r-q+0.5*s^2)*(T-t))/(s*sqrt(T-t))

d2 <- d1-s*sqrt(T-t)
S*exp(-q*(T-t))*pnorm(d1)-K*exp(-r*(T-t))*pnorm(d2)

}
fS <- function(S)
	bsc(S,0.5,0.0,45,0.06,0.25,0.02)
fT <- function(T)
	bsc(50,T,0.0,45,0.06,0.25,0.02)
ft <- function(t)
	bsc(50,0.5,t,45,0.06,0.25,0.02)
fK <- function(K)
	bsc(50,0.5,0.0,K,0.06,0.25,0.02)
fr <- function(r)
	bsc(50,0.5,0.0,45,r,0.25,0.02)
fr2 <- function(r)
	call(50,0.5,0.0,45,r,0.25,0.02)
fs <- function(s)
	bsc(50,0.5,0.0,45,0.06,s,0.02)
fq <- function(q)
	bsc(50,0.5,0.0,45,0.06,0.25,q)
fg <- function(g)
	delta(g,0.5,0.0,45,0.06,0.25,0.02)

#Delta
dt <- 0.5;
S_list <- seq(from = 25, to = 100, by = dt);
f_data <- fS(S_list);

n <- length(f_data);
df1 <- (f_data[2:n]-f_data[1:(n-1)])/dt;
df2 <- (f_data[3:n]-f_data[1:(n-2)])/(2*dt);

delta <- function(S,T,t,K,r,s,q) {
d1 <- (log(S/K)+(r-q+0.5*s^2)*(T-t))/(s*sqrt(T-t))
exp(-q*(T-t))*pnorm(d1)
}

df_exact <- delta(S_list,0.5,0.0,45,0.06,0.25,0.02);
d1 <- first_order(fS,S_list,dt)
d2 <- second_order(fS,S_list,dt)
d3 <- fourth_order(fS,S_list,dt)

e1 <- df_exact[1:(n-1)] - df1;
e2 <- df_exact[2:(n-1)] - df2;

#Vega
ds <- 0.1
s_list <- seq(from = 0, to = 5, by = ds);
fs_data <- fs(s_list);	

n2 <- length(fs_data);

vf_exact <- vega(50,0.5,0.0,45,0.06,s_list,0.02)
v1 <- first_order(fs,s_list,ds)
v2 <- second_order(fs,s_list,ds)
v3 <- fourth_order(fs,s_list,ds)

e1 <- vf_exact[1:(n2-1)] - dv1;


#Theta
dt <- 0.01
t_list <- seq(from = 0, to = 0.4, by = dt);
ft_data <- ft(t_list);
n <- length(ft_data);

dT_exact <- theta(50,0.5,t_list,45,0.06,0.25,0.02)
T1 <- first_order(ft,t_list,dt)
T2 <- second_order(ft,t_list,dt)
T3 <- fourth_order(ft,t_list,dt)

#Rho
dr <- 0.01
r_list <- seq(from = 0, to = 0.4, by = dr);
fr_data <- fr(r_list);
n <- length(fr_data);

dr_exact <- rho(50,0.5,0.0,45,r_list,0.25,0.02)
r1 <- first_order(fr,r_list,dr)
r2 <- second_order(fr,r_list,dr)
r3 <- fourth_order(fr,r_list,dr)

#gamma
dg <- 1
g_list <- seq(from = 25, to = 100, by = dg);
fg_data <- fg(g_list);
n <- length(fg_data);

dg_exact <- gamma(g_list,0.5,0.0,45,0.06,0.25,0.02)
g1 <- first_order(fg,g_list,dg)
g2 <- second_order(fg,g_list,dg)
g3 <- fourth_order(fg,g_list,dg)

first_order <- function(f,S,dS) {
(f(S+dS)-f(S))/dS
}

second_order <- function(f,S,dS) {
(f(S+dS)-f(S-dS))/(2*dS)
}

fourth_order <- function(f,S,dS) {
(8*f(S+dS) - 8*f(S-dS) - f(S+2*dS) + f(S-2*dS))/(12*dS)
}


#4a
vega <- function(S,T,t,K,r,s,q) {
d1 <- (log(S/K)+(r-q+0.5*s^2)*(T-t))/(s*sqrt(T-t))
d2 <- d1-s*sqrt(T-t)
phi <-exp(-d1^2/2)/sqrt(2*pi)
S*exp(-q*(T-t)) * phi * sqrt(T-t)
}

rho <- function(S,T,t,K,r,s,q) {
d1 <- (log(S/K)+(r-q+0.5*s^2)*(T-t))/(s*sqrt(T-t))
d2 <- d1-s*sqrt(T-t)
K*(T-t)*exp(-r*(T-t))*pnorm(d2)
}

gamma <- function(S,T,t,K,r,s,q) {
d1 <- (log(S/K)+(r-q+0.5*s^2)*(T-t))/(s*sqrt(T-t))
d2 <- d1-s*sqrt(T-t)
phi <-exp(-d2^2/2)/sqrt(2*pi)
K*exp(-r*(T-t)) * phi / (S^2*s*sqrt(T-t))
}

theta <- function(S,T,t,K,r,s,q) {
d1 <- (log(S/K)+(r-q+0.5*s^2)*(T-t))/(s*sqrt(T-t))
d2 <- d1-s*sqrt(T-t)
phi <-exp(-d1^2/2)/sqrt(2*pi)
-exp(-q*(T-t)) * S*phi*s/(2*sqrt(T-t)) - r*K*exp(-r*(T-t))*pnorm(d2) + q*S*exp(-q*(T-t))*pnorm(d1)
}

#3C
fourth_order(fS,50,0.5)

#5
a <- -1
b <- 2
h <- (a + b)/20;

f <- function(x) {
	exp(-x^2/2)/sqrt(2*pi)
}

left <- function(f,a,b,n) { 
x <- a + (b-a)/n*(0:n-1); 
sum((b-a)/n*f(x)) 
}

right <- function(f,a,b,n) {
	x <- a + (b-a)/n*(1:n);
	sum((b-a)/n*f(x))
}

right(f,a,b,10)
right(f,a,b,100)
#scales linearly
pnorm(2) - pnorm(-1) - right(f,a,b,10)
pnorm(2) - pnorm(-1) - right(f,a,b,100)


#5 b
de_int <- function(a,n) {
	right(f,-100,a,n)
}

#5 c
call <- function(S,T,t,K,r,s,q) {
	d1 <- (log(S/K)+(r-q+0.5*s^2)*(T-t))/(s*sqrt(T-t))
	d2 <- d1-s*sqrt(T-t)
	phi_d1 <- de_int(d1,1640)
	phi_d2 <- de_int(d2,1640) 
	S*exp(-q*(T-t))* phi_d1 - K*exp(-r*(T-t))*phi_d2
}

#5 D
rho2 <- function(S,T,t,K,r,s,q) {
	K*(T-t)*exp(-r*(T-t))*call(S,T,t,K,r,s,q)
}

dr2 <- 0.01
r2_list <- seq(from = 0, to = 0.4, by = dr2);
fr2_data <- fr2(r2_list);
n <- length(fr2_data);

dr2_exact <- rho2(50,0.5,0.0,45,r2_list,0.25,0.02)
r21 <- first_order(fr2,r2_list,dr2)
r22 <- second_order(fr2,r2_list,dr2)
r23 <- fourth_order(fr2,r2_list,dr2)

